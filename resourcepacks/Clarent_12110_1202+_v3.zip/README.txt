# Clarent for Excalibur

"As Excalibur forges ahead, Clarent preserves the past."
══════════════════════════════════════════════════════════════════════════

Clarent is created and maintained by GrandPappyJay.
(Formerly known as "Fabric Friendly Excalibur.")

- Requires the base Excalibur Resource Pack by Maffhew.
- Report bugs or issues to @GrandPappyJay via the official Excalibur Discord.
- Clarent will continue to be updated as time and necessity allow.

══════════════════════════════════════════════════════════════════════════

All credit to Maffhew for Excalibur.

Download Excalibur (Maffhew):
- [CurseForge](https://www.curseforge.com/minecraft/texture-packs/excalibur)
- [Planet Minecraft](https://www.planetminecraft.com/texture-pack/excalibur/)
- [Modrinth](https://modrinth.com/resourcepack/excal)

Everything included in Clarent falls under Excalibur's license because:
- Assets are taken directly from Excalibur.
- Assets are edits of Excalibur textures or models.
- Assets are recreations or faithful adaptations of Excalibur material.
- Assets are heavily inspired by Excalibur’s style and design.

══════════════════════════════════════════════════════════════════════════

Special Thanks:
- **Maffhew** — For Excalibur and permission to maintain Clarent.
- **TrinalDust** — For inspiration and early project support.

══════════════════════════════════════════════════════════════════════════

Clarent is a fan-made patch, distributed under the terms of Excalibur’s license.

Excalibur License:
Excalibur by Matt Dillow (Maffhew) is licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
http://creativecommons.org/licenses/by-nc-nd/3.0/us/

Summary:
- You may not redistribute this pack and claim it as your own.
- You may not redistribute this pack without linking to the official Excalibur CurseForge or Planet Minecraft page.
- You may not place money-making links (such as adf.ly) on this pack under any circumstances.
- You may not use this work for commercial purposes.
- You may not alter, transform, or build upon this work.

Noncommercial Waiver:
- You may use this Resource Pack in any Minecraft-related video, including those created for commercial or monetized purposes, as long as you provide a direct link to an official Excalibur download page.

Any of the above conditions may be waived with permission from Maffhew.
Discord: @maffhew

══════════════════════════════════════════════════════════════════════════
