
			**** Excalibur Apotheosis Support License ****

All Rights Reserved

Noncommercial Waiver
- You may use this Resource Pack as a part of any Minecraft-related video including those which are created for commercial purposes or 
are monetized by advertising, as long as there's a direct link to an official Excalibur and the Create Excalibur Support download page.

If you have any inquires, contact me through Discord.
Discord: @Pablito


			**** Excalibur License ****

Excalibur by Matt Dillow (Maffhew) is licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
http://creativecommons.org/licenses/by-nc-nd/3.0/us/

In other words:
- You may not redistribute this pack and claim it as your own.
- You may not redistribute this pack without a link to the official CurseForge or Planet Minecraft Excalibur page.
- You may not put money-making links such as adf.ly with this work under any circumstances.
- You may not use this work for commercial purposes.
- You may not alter, transform, or build upon this work.

Noncommercial Waiver
- You may use this Resource Pack as a part of any Minecraft-related video including those which are created for commercial purposes or 
are monetized by advertising, as long as there's a direct link to an official Excalibur download page.

Any of the above conditions can be waived if you get permission from Maffhew.
Discord: @maffhew

			**** Installation ****

Ingame

-> Click "Options..."

-> Click "Resource Packs..."

-> Click "Open Resource Pack Folder"

-> Drag and Drop the Excalibur_Apotheosis Addon_v**.zip file into the "resourcepacks" folder

-> Move the Excalibur Apotheosis resource pack from the left column to the right

-> Make sure that the support pack is placed above the original Excalibur resource pack

-> Select "Done"


			**** Thanks to ****

- Maffhew for making "Excalibur", an awesome resourcepack
- Shadows_of_Fire the Author of Apotheosis
- Abyssal_Kutku, who help me on this project
- The discord community of Excalibur, for their feedbacks, their enthusiastic support