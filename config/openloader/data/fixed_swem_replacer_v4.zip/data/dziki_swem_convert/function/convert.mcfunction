execute as @e[type=minecraft:horse] at @s store success entity @s[y=-64,dy=320] Pos[1] double -2112 run summon swem:swem_horse
schedule function dziki_swem_convert:convert 100t
