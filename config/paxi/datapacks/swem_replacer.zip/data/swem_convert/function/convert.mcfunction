execute as @e[type=minecraft:horse] at @s run summon swem:swem_horse ~ ~ ~
execute as @e[type=minecraft:horse] run tp @s ~ -2112 ~
schedule function dziki_swem_convert:convert 100t