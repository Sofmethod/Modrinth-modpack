#version 120

uniform sampler2D texture;

varying vec3 tintColor;
varying vec4 texcoord;
// Removed unused 'normal' input

void main() {
    vec4 blockColor = texture2D(texture, texcoord.st);
    blockColor.rgb *= tintColor;

    // Only write color.
    // Removed gl_FragData[1] (0.0) and [2] (normals)
    gl_FragData[0] = blockColor;
}