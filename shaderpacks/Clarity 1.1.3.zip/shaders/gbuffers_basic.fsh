#version 330 compatibility

in vec4 glcolor;

/* DRAWBUFFERS:0 */
layout(location = 0) out vec4 color;

void main() {
    color = glcolor;

    if (color.a < 0.1) {
        discard;
    }
}
