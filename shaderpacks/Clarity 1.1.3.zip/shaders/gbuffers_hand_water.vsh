#version 120

varying vec4 tintColor;
varying vec4 texcoord;

void main() {
    gl_Position = ftransform();

    texcoord = gl_MultiTexCoord0;
    tintColor = gl_Color;
}