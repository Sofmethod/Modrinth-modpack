#version 330 compatibility

uniform sampler2D gtexture;

#define RAIN_SNOW_OPACITY 0.30 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

in vec2 texcoord;
in vec4 glcolor;

layout(location = 0) out vec4 color;

void main() {
    vec4 texColor = texture(gtexture, texcoord) * glcolor;

    texColor.a *= RAIN_SNOW_OPACITY;

    if (texColor.a < 0.01) discard;

    color = texColor;
}
