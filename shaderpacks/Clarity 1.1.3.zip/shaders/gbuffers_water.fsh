#version 330 compatibility

uniform sampler2D gtexture;

#define WATER_OPACITY 0.40  // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define WATER_TEXTURE 1  // [0 1]

in vec2 texcoord;
in vec4 glcolor;
in float blockId;

/* DRAWBUFFERS:0 */
layout(location = 0) out vec4 color;

void main() {
    // Check block type (using 0.5 tolerance for safety)
    bool isWater = (abs(blockId - 10001.0) < 0.5);
    bool isGlass = (abs(blockId - 10002.0) < 0.5);

    vec4 texel = texture(gtexture, texcoord);
    vec3 finalRGB;
    float finalAlpha;

    if (isGlass) {
        // --- GLASS LOGIC ---
        // Multiply texture (detail/frame) by glcolor (the stain)
        finalRGB = texel.rgb * glcolor.rgb;
        
        // This is the fix! Multiply texture alpha by vertex alpha 
        // to keep the frames opaque and the center clear.
        finalAlpha = texel.a * glcolor.a;
    } 
    else if (isWater) {
        // --- WATER LOGIC ---
        if (WATER_TEXTURE == 1) {
            finalRGB = texel.rgb * glcolor.rgb;
            finalAlpha = texel.a * glcolor.a * WATER_OPACITY * 1.5;
        } else {
            // Hidden texture mode
            finalRGB = glcolor.rgb * 0.8;
            finalAlpha = glcolor.a * WATER_OPACITY;
        }
    } 
    else {
        // --- EVERYTHING ELSE (Ice, Slime, Clouds) ---
        finalRGB = texel.rgb * glcolor.rgb;
        finalAlpha = texel.a * glcolor.a;
    }

    color = vec4(finalRGB, clamp(finalAlpha, 0.0, 1.0));
}