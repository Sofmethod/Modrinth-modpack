#include "/prelude/core.glsl"
#define STARS 1 // [0 1]

/* RENDERTARGETS: 0 */
layout(location = 0) out vec3 colortex0;

uniform int renderStage;
uniform float viewHeight, viewWidth;
uniform vec3 fogColor, skyColor, upPosition;
uniform mat4 gbufferProjectionInverse;

uniform vec3 sunPosition;
uniform vec3 moonPosition;

in VertexData {
    layout(location = 0, component = 0) flat vec3 tint;
} v;

float fogify(float x, float w) {
    return w / (x * x + w);
}

vec3 sky(vec3 n_view) {
    immut float up_dot = dot(n_view, 0.01 * upPosition);
    return mix(skyColor, fogColor, fogify(max(up_dot, 0.0), 0.25));
}

void main() {
    immut vec2 ndc = fma(gl_FragCoord.xy, 2.0 / vec2(viewWidth, viewHeight), vec2(-1.0));

    immut vec3 view = vec3(
        vec2(gbufferProjectionInverse[0].x, gbufferProjectionInverse[1].y) * ndc,
        gbufferProjectionInverse[3].z
    ) / (gbufferProjectionInverse[2].w + gbufferProjectionInverse[3].w);

    vec3 dir = normalize(view);
    vec3 skyCol = sky(dir);

    if (renderStage == MC_RENDER_STAGE_STARS) {
        #if STARS == 1 
            float isSun = dot(dir, normalize(sunPosition));
            float isMoon = dot(dir, normalize(moonPosition));
            if (isSun > 0.98 || isMoon > 0.98) {
                discard;
            }
            vec3 stars = max(v.tint, vec3(0.0)) * 1.5;
            colortex0 = skyCol + stars;
        #else
            discard;
        #endif
    } else {
        colortex0 = skyCol;
    }
}