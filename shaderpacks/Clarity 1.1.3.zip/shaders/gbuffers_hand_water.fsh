#version 120

uniform sampler2D texture;

varying vec4 tintColor;
varying vec4 texcoord;

void main() {
    vec4 blockColor = texture2D(texture, texcoord.st);
    blockColor.rgb *= tintColor.rgb;
    blockColor.a *= tintColor.a;
    gl_FragData[0] = blockColor;
}