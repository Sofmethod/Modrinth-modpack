#version 330 compatibility

uniform sampler2D gtexture;
uniform vec4 entityColor;

in vec2 texcoord;
in vec4 glcolor;

layout(location = 0) out vec4 color;

void main() {
    color = texture(gtexture, texcoord) * glcolor;
    color.rgb = mix(color.rgb, entityColor.rgb, entityColor.a);
    if (color.a < 0.1) {
        discard;
    }
}
