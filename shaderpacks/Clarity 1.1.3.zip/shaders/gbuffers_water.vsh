#version 330 compatibility

out vec2 texcoord;
out vec4 glcolor;
out float blockId; 

attribute vec4 mc_Entity; // This attribute reads from block.properties

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor = gl_Color;
    
    // This tells the fragment shader which block we are drawing
    blockId = mc_Entity.x; 
}