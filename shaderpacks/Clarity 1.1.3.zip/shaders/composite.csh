#include "/prelude/core.glsl"

#define EXPOSURE 0.00 // [-1.00 -0.95 -0.90 -0.85 -0.80 -0.75 -0.70 -0.65 -0.60 -0.55 -0.50 -0.45 -0.40 -0.35 -0.30 -0.25 -0.20 -0.15 -0.10 -0.05 0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define VIBRANCE 0.00 // [-1.00 -0.95 -0.90 -0.85 -0.80 -0.75 -0.70 -0.65 -0.60 -0.55 -0.50 -0.45 -0.40 -0.35 -0.30 -0.25 -0.20 -0.15 -0.10 -0.05 0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define MOTION_BLUR 0.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define UNDERWATER_VIGNETTE 1 // [0 1]

#if ANTIALIASING == 1
    #define SMAA_ENABLED
#endif

layout(local_size_x = 16, local_size_y = 16, local_size_z = 1) in;
const vec2 workGroupsRender = vec2(1.0, 1.0);

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform layout(rg8) restrict writeonly image2D edge;
uniform layout(rgba16) restrict writeonly image2D tempCol;

uniform int isEyeInWater; // 1 if underwater, 0 if not
uniform vec2 pixSize;     // Screen resolution info

// Reprojection Matrices
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;

float redmeanSq(vec3 a, vec3 b) {
    immut float r = step(0.5, mix(a.r, b.r, 0.5));
    immut vec3 d = a - b;
    return dot(d*d, vec3(2.0 + r, 4.0, 3.0 - r));
}

void main() {
    immut ivec2 texel = ivec2(gl_GlobalInvocationID.xy);
    vec3 color = texelFetch(colortex0, texel, 0).rgb;
    vec2 uv = (vec2(texel) + 0.5) * pixSize;
    float depth = texelFetch(depthtex0, texel, 0).r;

    #if MOTION_BLUR > 0.0
    if (depth < 1.0) {
        // Reconstruct current frame's position
        vec4 ndc = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
        vec4 viewPos = gbufferProjectionInverse * ndc;
        viewPos /= viewPos.w;
        vec4 worldPos = gbufferModelViewInverse * viewPos;

        // Reproject into previous frame's space
        vec4 prevViewPos = gbufferPreviousModelView * worldPos;
        vec4 prevNdc = gbufferPreviousProjection * prevViewPos;
        prevNdc /= prevNdc.w;
        vec2 prevUv = prevNdc.xy * 0.5 + 0.5;

        // Calculate screen space velocity vector
        vec2 velocity = uv - prevUv;
        velocity *= MOTION_BLUR * 0.40; // Multiplier doubled so 1.0 scales out to 0.40 intensity

        // Clamp velocity vector to prevent wild stretching artifacts during teleporting/quick turns
        float maxVel = 0.06;
        float velLen = length(velocity);
        if (velLen > maxVel) {
            velocity = (velocity / velLen) * maxVel;
        }

        // Interleaved Gradient Noise (IGN) Dithering
        float dither = fract(52.9829189 * fract(float(texel.x) * 0.06711056 + float(texel.y) * 0.00583715));

        const int SAMPLES = 8;
        float totalWeight = 1.0;
        for (int i = 1; i < SAMPLES; ++i) {
            // Stochastic jittering offset to completely eliminate stepping artifacts
            float gradientStep = (float(i) + dither) / float(SAMPLES);
            vec2 sampleUV = uv + velocity * (gradientStep - 0.5);
            
            color += textureLod(colortex0, sampleUV, 0.0).rgb;
            totalWeight += 1.0;
        }
        color /= totalWeight;
    }
    #endif

    vec3 adjustedColor = color;
    adjustedColor *= (1.0 + EXPOSURE);
    float l = dot(adjustedColor, vec3(0.2126, 0.7152, 0.0722));
    adjustedColor = mix(vec3(l), adjustedColor, 1.0 + VIBRANCE);

    #if UNDERWATER_VIGNETTE == 1
    if (isEyeInWater == 1) {
        vec2 uvVignette = (vec2(texel) + 0.5) * pixSize;
        float dist = distance(uvVignette, vec2(0.5));
        float vignetteStrength = smoothstep(0.15, 0.85, dist);
        vec3 deepBlue = vec3(0.02, 0.15, 0.5); 
        adjustedColor = mix(adjustedColor, deepBlue * l, vignetteStrength * 0.85);
    }
    #endif

    imageStore(tempCol, texel, vec4(linear(adjustedColor), 0.0));

#ifdef SMAA_ENABLED
    immut vec3 left = texelFetchOffset(colortex0, texel, 0, ivec2(-1, 0)).rgb;
    immut vec3 top = texelFetchOffset(colortex0, texel, 0, ivec2(0, -1)).rgb;

    vec4 delta;
    delta.xy = vec2(redmeanSq(color, left), redmeanSq(color, top));

    const float THRESHOLD_SQ = SMAA_THRESHOLD * SMAA_THRESHOLD;
    immut bvec2 edges = greaterThanEqual(delta.xy, vec2(THRESHOLD_SQ));
    vec2 edgeOutput = vec2(0.0);

    if (any(edges)) {
        delta.zw = vec2(
            redmeanSq(color, texelFetchOffset(colortex0, texel, 0, ivec2(1, 0)).rgb),
            redmeanSq(color, texelFetchOffset(colortex0, texel, 0, ivec2(0, 1)).rgb)
        );
        vec2 delta_max = max(delta.xy, delta.zw);
        delta.zw = vec2(
            redmeanSq(left, texelFetchOffset(colortex0, texel, 0, ivec2(-2, 0)).rgb),
            redmeanSq(top, texelFetchOffset(colortex0, texel, 0, ivec2(0, -2)).rgb)
        );
        delta_max = max(delta_max.xy, delta.zw);

        const float local_contrast_factor_sq = 4.0;
        immut bvec2 temp = greaterThanEqual(delta.xy, (max(delta_max.x, delta_max.y) / local_contrast_factor_sq).xx);
        bvec2 result = bvec2(edges.x && temp.x, edges.y && temp.y);
        
        edgeOutput = vec2(result);
    }

    // Unconditionally write to every single texel to completely eliminate VRAM reload garbage leaks
    imageStore(edge, texel, vec4(edgeOutput, 0.0, 0.0));
#endif
}