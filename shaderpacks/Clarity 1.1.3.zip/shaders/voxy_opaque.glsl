layout(location = 0) out vec4 outColor;

void voxy_emitFragment(VoxyFragmentParameters parameters) {
    vec4 color = parameters.sampledColour * parameters.tinting;

    // Directional shading (Vanilla style)
    float shade = 1.0;
    if (parameters.face == 0u) shade = 0.5;      // Down
    else if (parameters.face == 2u || parameters.face == 3u) shade = 0.8; // N/S
    else if (parameters.face == 4u || parameters.face == 5u) shade = 0.6; // E/W

    color.rgb *= shade;
    outColor = vec4(color.rgb, 1.0);
}