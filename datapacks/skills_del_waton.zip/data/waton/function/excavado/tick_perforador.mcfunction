execute as @a[tag=waton_excavado_perforador] run scoreboard players enable @s waton_perforador
execute as @a[tag=waton_excavado_perforador] run scoreboard players operation @s waton_perforador %= #two waton_data
execute as @a[tag=waton_excavado_perforador] unless score @s waton_perforador = @s waton_perf_prev run function waton:excavado/perforador/notify
execute as @a[tag=waton_excavado_perforador] run scoreboard players operation @s waton_perf_prev = @s waton_perforador
