execute if entity @s[tag=waton_excavado_perforador] if score @s waton_perforador matches 1 run function waton:excavado/perforador/dig
advancement revoke @s only waton:excavado/perforador_trigger
