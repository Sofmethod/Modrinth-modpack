execute store result score #waton_tmp waton_data run clear @s minecraft:red_sand 1
execute if score #waton_tmp waton_data matches 1 run give @s minecraft:glass 1
execute if score #waton_tmp waton_data matches 1 run function waton:excavado/autosmelt/drain_red_sand
