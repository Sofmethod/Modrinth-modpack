execute store result score #waton_tmp waton_data run clear @s minecraft:clay_ball 1
execute if score #waton_tmp waton_data matches 1 run give @s minecraft:brick 1
execute if score #waton_tmp waton_data matches 1 run function waton:excavado/autosmelt/drain_clay
