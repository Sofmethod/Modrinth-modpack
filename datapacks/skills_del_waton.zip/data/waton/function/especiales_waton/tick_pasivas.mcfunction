execute as @a[tag=waton_esp_sin_veneno] run effect clear @s minecraft:poison
execute as @a[tag=waton_esp_estomago] run effect clear @s minecraft:hunger
execute as @a[tag=waton_esp_estomago] run effect clear @s minecraft:nausea
execute as @a[tag=waton_esp_regen] run scoreboard players remove @s waton_esp_regen_cd 1
execute as @a[tag=waton_esp_regen,scores={waton_esp_regen_cd=..0}] unless entity @s[nbt={foodLevel:0}] run function waton:especiales_waton/heal_exact {amount:2}
execute as @a[tag=waton_esp_regen,scores={waton_esp_regen_cd=..0}] run scoreboard players set @s waton_esp_regen_cd 200
execute as @a[tag=waton_esp_no_enredo] at @s if block ~ ~ ~ minecraft:cobweb run effect give @s minecraft:speed 1 3 true
execute as @a[tag=waton_esp_no_enredo] at @s if block ~ ~-1 ~ minecraft:soul_sand run effect give @s minecraft:speed 1 2 true
execute as @a[tag=waton_esp_no_enredo] at @s if block ~ ~-1 ~ minecraft:soul_soil run effect give @s minecraft:speed 1 2 true
