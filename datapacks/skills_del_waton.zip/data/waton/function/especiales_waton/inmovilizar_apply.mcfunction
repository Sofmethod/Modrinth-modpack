effect give @s minecraft:slowness 2 9 true
particle minecraft:item_slime ~ ~1 ~ 0.3 0.3 0.3 0 12 force
