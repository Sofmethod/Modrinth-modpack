item replace entity @s weapon.mainhand with air
particle minecraft:crit ~ ~1 ~ 0.2 0.2 0.2 0.05 10 force
playsound minecraft:entity.item.break master @s ~ ~ ~ 1 1
