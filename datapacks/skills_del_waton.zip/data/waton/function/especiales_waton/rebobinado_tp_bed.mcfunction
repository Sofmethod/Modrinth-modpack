$execute in minecraft:overworld run tp @s $(SpawnX) $(SpawnY) $(SpawnZ)
