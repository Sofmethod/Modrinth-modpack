summon minecraft:block_display ~ ~ ~ {block_state:{Name:"minecraft:glowstone"},Tags:["waton_vetas_marker"],Glowing:1b,brightness:{block:15,sky:15}}
