$summon minecraft:item ~ ~0.3 ~ {Item:$(),Motion:[0.0,0.25,0.0],PickupDelay:20}
