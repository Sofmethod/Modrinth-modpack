execute as @a[tag=waton_esp_vetas] run scoreboard players remove @s waton_esp_vetas_cd 1
execute as @a[tag=waton_esp_vetas,scores={waton_esp_vetas_cd=..0}] at @s run kill @e[tag=waton_vetas_marker,distance=..10]
execute as @a[tag=waton_esp_vetas,scores={waton_esp_vetas_cd=..0}] at @s run function waton:especiales_waton/scan_vetas_paredes
execute as @a[tag=waton_esp_vetas,scores={waton_esp_vetas_cd=..0}] run scoreboard players set @s waton_esp_vetas_cd 60
