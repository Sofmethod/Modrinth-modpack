execute as @s if entity @s[tag=waton_esp_rebobinado] if score @s waton_esp_rebob_cd matches ..0 run function waton:especiales_waton/rebobinado_apply
advancement revoke @s only waton:especiales_waton/used_totem_trigger
