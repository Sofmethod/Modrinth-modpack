execute store result score @s waton_heal_cur run data get entity @s Health 1
execute store result score @s waton_heal_max run attribute @s minecraft:generic.max_health get 1
$scoreboard players add @s waton_heal_cur $(amount)
execute if score @s waton_heal_cur > @s waton_heal_max run scoreboard players operation @s waton_heal_cur = @s waton_heal_max
execute store result entity @s Health float 1 run scoreboard players get @s waton_heal_cur
