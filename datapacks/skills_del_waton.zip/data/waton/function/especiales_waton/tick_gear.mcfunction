execute as @a[tag=waton_esp_punteria] if items entity @s weapon.mainhand #minecraft:enchantable/crossbow run item modify entity @s weapon.mainhand waton:esp_apply_piercing

execute as @a[tag=waton_esp_recarga] if items entity @s weapon.mainhand #minecraft:enchantable/crossbow run item modify entity @s weapon.mainhand waton:esp_apply_quick_charge

execute as @a[tag=waton_esp_escudo_sin_penal,predicate=waton:especiales_waton/using_item] if items entity @s weapon.offhand minecraft:shield run effect give @s minecraft:speed 1 3 true
execute as @a[tag=waton_esp_escudo_sin_penal,predicate=waton:especiales_waton/using_item] if items entity @s weapon.mainhand minecraft:shield run effect give @s minecraft:speed 1 3 true

execute as @a[tag=waton_esp_arco_sin_penal,predicate=waton:especiales_waton/using_item] if items entity @s weapon.mainhand minecraft:bow run effect give @s minecraft:speed 1 3 true
execute as @a[tag=waton_esp_ballesta_sin_penal,predicate=waton:especiales_waton/using_item] if items entity @s weapon.mainhand minecraft:crossbow run effect give @s minecraft:speed 1 3 true

execute as @a[tag=waton_esp_huida] if score @s waton_bow_used_stat > @s waton_bow_used_prev run function waton:especiales_waton/huida_check
execute as @a[tag=waton_esp_huida] if score @s waton_crossbow_used_stat > @s waton_crossbow_used_prev run function waton:especiales_waton/huida_check
execute as @a[tag=waton_esp_huida] run scoreboard players operation @s waton_bow_used_prev = @s waton_bow_used_stat
execute as @a[tag=waton_esp_huida] run scoreboard players operation @s waton_crossbow_used_prev = @s waton_crossbow_used_stat

execute as @a[tag=waton_esp_glow] at @s if items entity @s weapon.mainhand #minecraft:swords run function waton:especiales_waton/glow_apply
execute as @a[tag=waton_esp_glow] at @s if items entity @s weapon.mainhand #minecraft:axes run function waton:especiales_waton/glow_apply
execute as @a[tag=waton_esp_glow] at @s if items entity @s weapon.mainhand minecraft:bow run function waton:especiales_waton/glow_apply
execute as @a[tag=waton_esp_glow] at @s if items entity @s weapon.mainhand minecraft:crossbow run function waton:especiales_waton/glow_apply
