execute as @s store result score @s waton_rng run random value 1..100
execute as @s if entity @s[tag=waton_esp_aturdir] if score @s waton_rng matches ..25 at @s as @e[type=!minecraft:player,distance=..4,sort=nearest,limit=1] run effect give @s minecraft:slowness 2 10 true
execute as @s if entity @s[tag=waton_esp_aturdir] if score @s waton_rng matches ..25 at @s as @e[type=!minecraft:player,distance=..4,sort=nearest,limit=1] run effect give @s minecraft:weakness 2 4 true
execute as @s store result score @s waton_rng run random value 1..100
execute as @s if entity @s[tag=waton_esp_freno] if score @s waton_rng matches ..50 at @s as @e[type=!minecraft:player,distance=..4,sort=nearest,limit=1] run effect give @s minecraft:slowness 3 1 true
execute as @s store result score @s waton_rng run random value 1..8
execute as @s if entity @s[tag=waton_esp_corte] if score @s waton_rng matches 1 at @s as @e[distance=..4,sort=nearest,limit=1] run function waton:especiales_waton/corte_apply
execute as @s if entity @s[tag=waton_esp_desarmar] at @s as @e[type=!minecraft:player,distance=..4,sort=nearest,limit=1] run function waton:especiales_waton/desarmar_apply
