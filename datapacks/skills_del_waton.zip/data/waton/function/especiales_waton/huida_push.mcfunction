execute at @s run teleport @s ^ ^0.2 ^-2.2
playsound minecraft:entity.phantom.flap player @s ~ ~ ~ 0.7 1.6
particle minecraft:cloud ~ ~1 ~ 0.3 0.3 0.3 0 8 force
