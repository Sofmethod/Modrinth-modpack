execute as @s if entity @s[tag=waton_esp_inmovilizar] at @s as @e[type=!minecraft:player,distance=..6,sort=nearest,limit=1] run function waton:especiales_waton/inmovilizar_apply
advancement revoke @s only waton:especiales_waton/arrow_hit_trigger
