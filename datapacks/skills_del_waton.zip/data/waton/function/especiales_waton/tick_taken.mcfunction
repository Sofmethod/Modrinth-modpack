execute as @a if score @s waton_dmg_taken_stat > @s waton_dmg_taken_prev run function waton:especiales_waton/on_taken
execute as @a run scoreboard players operation @s waton_dmg_taken_prev = @s waton_dmg_taken_stat
