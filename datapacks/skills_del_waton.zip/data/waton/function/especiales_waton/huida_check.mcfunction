execute at @s if entity @e[type=!minecraft:player,distance=..2] run function waton:especiales_waton/huida_apply
