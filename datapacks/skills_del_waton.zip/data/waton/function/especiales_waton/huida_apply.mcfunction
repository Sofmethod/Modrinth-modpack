execute as @s at @s facing entity @e[type=!minecraft:player,distance=..2,sort=nearest,limit=1] feet run function waton:especiales_waton/huida_push
