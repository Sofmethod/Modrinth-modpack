execute as @s if entity @s[tag=waton_esp_rabia] run effect give @s minecraft:strength 4 1 true
