data merge entity @s {Fire:60}
particle minecraft:flame ~ ~1 ~ 0.3 0.3 0.3 0.02 15 force
playsound minecraft:item.firecharge.use master @s ~ ~ ~ 1 0.8
