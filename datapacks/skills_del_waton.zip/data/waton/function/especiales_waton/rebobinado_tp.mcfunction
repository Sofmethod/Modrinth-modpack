execute if entity @s[nbt={SpawnDimension:"minecraft:overworld"}] run function waton:especiales_waton/rebobinado_tp_bed with entity @s
