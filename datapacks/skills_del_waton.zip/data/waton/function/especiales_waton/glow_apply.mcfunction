effect give @e[type=!minecraft:player,distance=..12,sort=nearest,limit=5] minecraft:glowing 2 0 true
