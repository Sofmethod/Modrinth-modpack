execute as @s if entity @s[tag=waton_esp_revancha] run function waton:especiales_waton/heal_exact {amount:10}
advancement revoke @s only waton:especiales_waton/kill_trigger
