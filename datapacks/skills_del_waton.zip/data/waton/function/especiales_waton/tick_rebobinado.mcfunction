execute as @a[tag=waton_esp_rebobinado] unless score @s waton_esp_rebob_cd matches 1.. unless items entity @s weapon.offhand minecraft:totem_of_undying run item replace entity @s weapon.offhand with minecraft:totem_of_undying
execute as @a[scores={waton_esp_rebob_cd=1..}] run scoreboard players remove @s waton_esp_rebob_cd 1
