scoreboard players set @s waton_esp_rebob_cd 36000
title @s title {"text":"¡El Rebobinado del Funado!","color":"aqua"}
playsound minecraft:item.totem.use master @s ~ ~ ~ 1 1
