execute as @s if entity @s[tag=waton_guerrero_racha] run function waton:guerrero/racha_stack
execute as @s at @s if score @s waton_guerrero_dmg_bonus matches 30 if items entity @s weapon.mainhand #minecraft:swords run function waton:guerrero/kill_sound_maestro
advancement revoke @s only waton:guerrero/kill_trigger
