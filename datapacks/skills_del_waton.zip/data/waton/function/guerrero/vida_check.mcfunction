execute as @s if score @s waton_guerrero_vida_lvl matches 1.. store result score @s waton_rng run random value 1..100
execute as @s if score @s waton_guerrero_vida_lvl matches 1 if score @s waton_rng matches ..20 run function waton:guerrero/vida_apply {amp:0}
execute as @s if score @s waton_guerrero_vida_lvl matches 2 if score @s waton_rng matches ..30 run function waton:guerrero/vida_apply {amp:0}
execute as @s if score @s waton_guerrero_vida_lvl matches 3 if score @s waton_rng matches ..40 run function waton:guerrero/vida_apply {amp:1}
execute as @s if score @s waton_guerrero_vida_lvl matches 4 if score @s waton_rng matches ..50 run function waton:guerrero/vida_apply {amp:1}
execute as @s if score @s waton_guerrero_vida_lvl matches 5 if score @s waton_rng matches ..60 run function waton:guerrero/vida_apply {amp:2}
