$effect give @s minecraft:instant_health 1 $(amp) true
function waton:guerrero/vida_feedback
