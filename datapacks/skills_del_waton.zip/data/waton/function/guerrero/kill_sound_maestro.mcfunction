title @s actionbar {"text":"¡Golpe de Maestro!","color":"gold","bold":true}
playsound waton:guerrero.golpe_maestro master @a[distance=..16] ~ ~ ~ 1 1
