attribute @s generic.attack_damage modifier remove waton:sword_damage_bonus
$attribute @s generic.attack_damage modifier add waton:sword_damage_bonus $(value) add_value
