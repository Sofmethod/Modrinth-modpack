execute store result storage waton:temp value int 1 run scoreboard players get @s waton_guerrero_dmg_bonus
function waton:guerrero/sword_damage/apply_macro with storage waton:temp
