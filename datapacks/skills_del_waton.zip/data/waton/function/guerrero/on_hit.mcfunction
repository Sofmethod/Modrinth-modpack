execute as @s at @s run function waton:guerrero/crit_check
execute as @s at @s run function waton:guerrero/vida_check
execute as @s at @s run function waton:especiales_waton/on_hit
