execute as @a if score @s waton_guerrero_dmg_bonus matches 1.. if items entity @s weapon.mainhand #minecraft:swords run function waton:guerrero/sword_damage/apply
execute as @a unless items entity @s weapon.mainhand #minecraft:swords run attribute @s generic.attack_damage modifier remove waton:sword_damage_bonus
execute as @a if score @s waton_guerrero_dmg_bonus matches ..0 run attribute @s generic.attack_damage modifier remove waton:sword_damage_bonus
