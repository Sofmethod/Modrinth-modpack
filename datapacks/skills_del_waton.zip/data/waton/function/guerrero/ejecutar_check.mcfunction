# reemplazado por vida_check.mcfunction (habilidad de rematar por vida baja retirada)
