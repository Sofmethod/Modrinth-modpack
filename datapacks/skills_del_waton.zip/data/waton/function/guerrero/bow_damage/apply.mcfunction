# Obsoleto (2.0): ver tick_bow_damage.mcfunction en la carpeta padre.
