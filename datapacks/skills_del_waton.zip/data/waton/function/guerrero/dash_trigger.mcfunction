execute as @s at @s if score @s waton_guerrero_dash_lvl matches 1 run tp @s ^ ^ ^5
execute as @s at @s if score @s waton_guerrero_dash_lvl matches 2 run tp @s ^ ^ ^7
execute as @s if score @s waton_guerrero_dash_lvl matches 1 run scoreboard players set @s waton_dash_cd 100
execute as @s if score @s waton_guerrero_dash_lvl matches 2 run scoreboard players set @s waton_dash_cd 60
