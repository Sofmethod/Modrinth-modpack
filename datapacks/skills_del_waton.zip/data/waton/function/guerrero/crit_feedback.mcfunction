title @s actionbar {"text":"¡Crítico!","color":"red"}
playsound minecraft:entity.player.attack.crit master @s ~ ~ ~ 2 1.3
particle minecraft:crit ~ ~1 ~ 0.3 0.3 0.3 0.1 15
