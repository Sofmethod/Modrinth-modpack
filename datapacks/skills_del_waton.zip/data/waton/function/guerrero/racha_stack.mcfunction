scoreboard players add @s waton_racha_stacks 1
execute if score @s waton_racha_stacks matches 5.. run scoreboard players set @s waton_racha_stacks 4
scoreboard players set @s waton_racha_timer 200
execute as @s if score @s waton_racha_stacks matches 1 run effect give @s minecraft:strength 200 0 true
execute as @s if score @s waton_racha_stacks matches 2 run effect give @s minecraft:strength 200 1 true
execute as @s if score @s waton_racha_stacks matches 3 run effect give @s minecraft:strength 200 2 true
execute as @s if score @s waton_racha_stacks matches 4 run effect give @s minecraft:strength 200 3 true
execute as @s if score @s waton_racha_stacks matches ..3 run effect give @s minecraft:speed 200 1 true
execute as @s if score @s waton_racha_stacks matches 4 run effect give @s minecraft:speed 200 2 true
execute as @s if score @s waton_racha_stacks matches 4 run effect give @s minecraft:absorption 200 1 true
