title @s actionbar {"text":"Viera: ¡a estudiar sociología a la USACH!","color":"dark_red"}
playsound minecraft:entity.generic.drink master @s ~ ~ ~ 1 1
particle minecraft:heart ~ ~1.2 ~ 0.3 0.3 0.3 0 6
