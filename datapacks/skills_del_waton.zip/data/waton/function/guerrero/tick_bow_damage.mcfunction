# Obsoleto (2.0): el bono de dano a distancia de Pierry (pierry_arco_1..3, examen_de_roberto,
# la_leyenda_de_pierry) ahora se aplica de forma nativa via puffish_skills:attribute en
# definitions.json (apothic_attributes:arrow_damage), sin scoreboard ni chequeo de arma en mano,
# porque el propio mod solo aplica el multiplicador en el instante en que se dispara una flecha/tridente.
# Este archivo ya no esta referenciado en data/minecraft/tags/function/tick.json.
