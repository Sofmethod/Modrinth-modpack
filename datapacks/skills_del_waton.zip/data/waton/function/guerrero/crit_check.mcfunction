execute as @s if score @s waton_guerrero_crit_lvl matches 1.. store result score @s waton_rng run random value 1..100
execute as @s at @s if score @s waton_guerrero_crit_lvl matches 1 if score @s waton_rng matches ..15 as @e[type=!minecraft:player,distance=..4,sort=nearest,limit=1] run damage @s 3 minecraft:generic
execute as @s at @s if score @s waton_guerrero_crit_lvl matches 2 if score @s waton_rng matches ..25 as @e[type=!minecraft:player,distance=..4,sort=nearest,limit=1] run damage @s 5 minecraft:generic
execute as @s at @s if score @s waton_guerrero_crit_lvl matches 3 if score @s waton_rng matches ..35 as @e[type=!minecraft:player,distance=..4,sort=nearest,limit=1] run damage @s 8 minecraft:generic
execute as @s if score @s waton_guerrero_crit_lvl matches 1 if score @s waton_rng matches ..15 run function waton:guerrero/crit_feedback
execute as @s if score @s waton_guerrero_crit_lvl matches 2 if score @s waton_rng matches ..25 run function waton:guerrero/crit_feedback
execute as @s if score @s waton_guerrero_crit_lvl matches 3 if score @s waton_rng matches ..35 run function waton:guerrero/crit_feedback
