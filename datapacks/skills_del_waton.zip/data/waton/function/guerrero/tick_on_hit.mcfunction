execute as @a if score @s waton_dmg_dealt_stat > @s waton_dmg_dealt_prev run function waton:guerrero/on_hit
execute as @a run scoreboard players operation @s waton_dmg_dealt_prev = @s waton_dmg_dealt_stat
