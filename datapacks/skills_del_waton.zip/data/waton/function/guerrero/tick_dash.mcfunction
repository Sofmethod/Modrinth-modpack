execute as @a[scores={waton_guerrero_dash_lvl=1..}] if score @s waton_dash_cd matches 0 if predicate waton:guerrero/sneak_sprint run function waton:guerrero/dash_trigger
execute as @a if score @s waton_dash_cd matches 1.. run scoreboard players remove @s waton_dash_cd 1
