# Obsoleto (2.0): ver tick_base_damage.mcfunction en la carpeta padre.
