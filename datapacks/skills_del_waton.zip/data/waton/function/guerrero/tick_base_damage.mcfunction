# Obsoleto (2.0): el bono de dano base de Opazo (entrenamiento_1..15) ahora se aplica
# de forma nativa via puffish_skills:attribute en definitions.json, sin pasar por scoreboard.
# Este archivo ya no esta referenciado en data/minecraft/tags/function/tick.json.
