execute as @a[tag=waton_guerrero_racha] if score @s waton_racha_timer matches 1.. run scoreboard players remove @s waton_racha_timer 1
execute as @a[tag=waton_guerrero_racha] if score @s waton_racha_timer matches 0 if score @s waton_racha_stacks matches 1.. run scoreboard players set @s waton_racha_stacks 0
execute as @a[tag=waton_guerrero_racha] if score @s waton_racha_timer matches 0 run effect clear @s minecraft:strength
