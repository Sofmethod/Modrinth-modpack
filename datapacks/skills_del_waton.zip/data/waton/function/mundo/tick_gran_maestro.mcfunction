# Logro cruzado: revisa cada ~5s (100 ticks) si algun jugador tiene los 8 "capstones"
# repartidos en los 5 arboles (uno por cada rama principal de cada profesor) y aun no fue premiado.
scoreboard players add #gran_maestro_ciclo waton_gremio_timer 1
execute if score #gran_maestro_ciclo waton_gremio_timer matches 100.. run scoreboard players set #gran_maestro_ciclo waton_gremio_timer 0
execute if score #gran_maestro_ciclo waton_gremio_timer matches 0 run function waton:mundo/gran_maestro_scan
