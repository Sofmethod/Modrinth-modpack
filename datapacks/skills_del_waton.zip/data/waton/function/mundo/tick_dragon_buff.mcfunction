# Reafirma el limite de vida y el daño de contacto en TODOS los dragones cada tick
# (asi un cambio de valores se aplica de inmediato, sin quedar pegado a un dragon ya etiquetado).
execute as @e[type=minecraft:ender_dragon] run function waton:mundo/dragon_stats_apply
# Solo la PRIMERA vez que aparece un dragon (sin la tag) lo cura al nuevo maximo, para no revivirlo en combate.
execute as @e[type=minecraft:ender_dragon,tag=!waton_dragon_buffed] run function waton:mundo/dragon_buff_apply
