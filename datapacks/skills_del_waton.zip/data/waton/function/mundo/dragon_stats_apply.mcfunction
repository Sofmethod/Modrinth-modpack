# Vida y daño de contacto del Ender Dragon, pensado para un grupo de al menos 3 jugadores
# con el arbol de habilidades avanzado (vanilla: 200 HP, mordida ~6-10).
attribute @s minecraft:generic.max_health base set 4000
attribute @s minecraft:generic.attack_damage base set 30
