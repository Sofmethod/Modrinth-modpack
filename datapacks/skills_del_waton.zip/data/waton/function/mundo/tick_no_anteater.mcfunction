# Elimina cualquier oso hormiguero (Alex's Mobs) que aparezca por cualquier via
# (spawn natural, spawner, estructura o /summon), ademas de desactivar su spawn natural en el config.
execute as @e[type=alexsmobs:anteater] run kill @s
