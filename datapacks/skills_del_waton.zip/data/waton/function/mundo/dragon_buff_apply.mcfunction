# Se ejecuta UNA sola vez por dragon (cuando aparece fresco) para curarlo a su nuevo maximo.
data merge entity @s {Health:4000.0f}
tag @s add waton_dragon_buffed
title @a actionbar {"text":"El Dragón del Fin ha despertado con nuevas fuerzas...","color":"dark_purple"}
