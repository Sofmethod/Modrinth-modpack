tag @s add waton_gran_maestro
attribute @s minecraft:generic.max_health modifier add waton:gran_maestro_bonus 2 add_value
effect give @s minecraft:regeneration 8 2 true
effect give @s minecraft:absorption 200 1 true
give @s minecraft:totem_of_undying[minecraft:custom_name='{"text":"Diploma de Gran Maestro","italic":false,"color":"gold"}',minecraft:lore=['{"text":"Firmado por Opazo, Pierri, Salas, Viera y Bassa","italic":true,"color":"gray"}','{"text":"\"Nunca pensamos que alguien terminaria las 5 catedras.\"","italic":true,"color":"dark_gray"}']] 1
playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
title @s times 10 70 20
title @s title {"text":"¡GRAN MAESTRO!","color":"gold","bold":true}
title @s subtitle {"text":"Dominaste los 5 arboles del Gremio","color":"yellow"}
tellraw @a [{"text":"[Gremio] ","color":"gold"},{"selector":"@s","color":"white"},{"text":" acaba de graduarse con honores de las 5 catedras (Opazo, Pierri, Salas, Viera y Bassa). Aplausos.","color":"gray"}]
