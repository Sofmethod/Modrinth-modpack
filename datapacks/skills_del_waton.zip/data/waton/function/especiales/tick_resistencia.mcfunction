execute as @a[tag=waton_especial_resistencia_explosion] if items entity @s weapon.mainhand #waton:gremio_tools run effect give @s minecraft:resistance 1 1 true
execute as @a[tag=waton_especial_resistencia_explosion] unless items entity @s weapon.mainhand #waton:gremio_tools run effect clear @s minecraft:resistance
