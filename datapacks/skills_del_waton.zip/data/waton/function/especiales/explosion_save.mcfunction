execute if entity @s[tag=waton_especial_resistencia_explosion] if items entity @s weapon.mainhand #waton:gremio_tools if score @s waton_health matches ..2 run data merge entity @s {Health:2.0f}
advancement revoke @s only waton:especiales/explosion_hit_trigger
