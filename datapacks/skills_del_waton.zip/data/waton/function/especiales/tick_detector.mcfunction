execute as @a[tag=waton_especial_detector] run scoreboard players remove @s waton_detector_cd 1
execute as @a[tag=waton_especial_detector,scores={waton_detector_cd=..0}] at @s run function waton:especiales/scan_vetas
execute as @a[tag=waton_especial_detector,scores={waton_detector_cd=..0}] run scoreboard players set @s waton_detector_cd 100
