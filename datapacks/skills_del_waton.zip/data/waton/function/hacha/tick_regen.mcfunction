execute as @a store success score @s waton_axe_held_now if items entity @s weapon.mainhand #minecraft:axes
execute as @a if score @s waton_hacha_regen_level matches 1.. if score @s waton_axe_held_now matches 1 run scoreboard players remove @s waton_regen_refresh 1
execute as @a if score @s waton_hacha_regen_level matches 1.. if score @s waton_axe_held_now matches 1 unless score @s waton_axe_held_now = @s waton_axe_held_prev run function waton:hacha/regen/apply
execute as @a if score @s waton_hacha_regen_level matches 1.. if score @s waton_axe_held_now matches 1 if score @s waton_regen_refresh matches ..0 run function waton:hacha/regen/apply
execute as @a if score @s waton_axe_held_now matches 0 unless score @s waton_axe_held_now = @s waton_axe_held_prev run effect clear @s minecraft:regeneration
execute as @a run scoreboard players operation @s waton_axe_held_prev = @s waton_axe_held_now
