scoreboard players set @s waton_regen_refresh 300
execute if score @s waton_hacha_regen_level matches 1 run effect give @s minecraft:regeneration 20 0 true
execute if score @s waton_hacha_regen_level matches 2 run effect give @s minecraft:regeneration 20 1 true
execute if score @s waton_hacha_regen_level matches 3 run effect give @s minecraft:regeneration 20 2 true
execute if score @s waton_hacha_regen_level matches 4.. run effect give @s minecraft:regeneration 20 3 true
