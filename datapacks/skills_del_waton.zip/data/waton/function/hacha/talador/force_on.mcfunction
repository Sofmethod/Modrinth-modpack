scoreboard players enable @s waton_talador
scoreboard players set @s waton_talador 1
