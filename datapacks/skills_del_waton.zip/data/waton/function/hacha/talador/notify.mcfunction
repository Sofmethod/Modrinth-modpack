execute if score @s waton_talador matches 1 run tellraw @s [{"text":"Waton Talador ","color":"aqua"},{"text":"ACTIVADO","color":"green","bold":true}]
execute if score @s waton_talador matches 0 run tellraw @s [{"text":"Waton Talador ","color":"aqua"},{"text":"DESACTIVADO","color":"red","bold":true}]
