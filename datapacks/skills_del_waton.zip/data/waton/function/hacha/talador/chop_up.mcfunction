execute store success score #waton_tmp waton_data if block ~ ~1 ~ #waton:wood_logs
execute if score #waton_tmp waton_data matches 1 run setblock ~ ~1 ~ air destroy
execute if score #waton_tmp waton_data matches 1 positioned ~ ~1 ~ run function waton:hacha/talador/chop_up

execute store success score #waton_tmp waton_data if block ~ ~-1 ~ #waton:wood_logs
execute if score #waton_tmp waton_data matches 1 run setblock ~ ~-1 ~ air destroy
execute if score #waton_tmp waton_data matches 1 positioned ~ ~-1 ~ run function waton:hacha/talador/chop_up

execute store success score #waton_tmp waton_data if block ~1 ~ ~ #waton:wood_logs
execute if score #waton_tmp waton_data matches 1 run setblock ~1 ~ ~ air destroy
execute if score #waton_tmp waton_data matches 1 positioned ~1 ~ ~ run function waton:hacha/talador/chop_up

execute store success score #waton_tmp waton_data if block ~-1 ~ ~ #waton:wood_logs
execute if score #waton_tmp waton_data matches 1 run setblock ~-1 ~ ~ air destroy
execute if score #waton_tmp waton_data matches 1 positioned ~-1 ~ ~ run function waton:hacha/talador/chop_up

execute store success score #waton_tmp waton_data if block ~ ~ ~1 #waton:wood_logs
execute if score #waton_tmp waton_data matches 1 run setblock ~ ~ ~1 air destroy
execute if score #waton_tmp waton_data matches 1 positioned ~ ~ ~1 run function waton:hacha/talador/chop_up

execute store success score #waton_tmp waton_data if block ~ ~ ~-1 #waton:wood_logs
execute if score #waton_tmp waton_data matches 1 run setblock ~ ~ ~-1 air destroy
execute if score #waton_tmp waton_data matches 1 positioned ~ ~ ~-1 run function waton:hacha/talador/chop_up
