execute store result score #waton_tmp waton_data run clear @s #minecraft:logs_that_burn 1
execute if score #waton_tmp waton_data matches 1 run give @s minecraft:charcoal 1
execute if score #waton_tmp waton_data matches 1 run function waton:hacha/autosmelt/drain_log
