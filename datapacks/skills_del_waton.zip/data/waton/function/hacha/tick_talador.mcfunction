execute as @a[tag=waton_hacha_talador] unless score @s waton_talador matches -2147483648..2147483647 run scoreboard players set @s waton_talador 1
execute as @a[tag=waton_hacha_talador] run scoreboard players enable @s waton_talador
execute as @a[tag=waton_hacha_talador] run scoreboard players operation @s waton_talador %= #two waton_data
execute as @a[tag=waton_hacha_talador] unless score @s waton_talador = @s waton_tal_prev run function waton:hacha/talador/notify
execute as @a[tag=waton_hacha_talador] run scoreboard players operation @s waton_tal_prev = @s waton_talador
