execute store result storage waton:temp value int 1 run scoreboard players get @s waton_axe_damage_bonus
function waton:hacha/axe_damage/apply_macro with storage waton:temp
