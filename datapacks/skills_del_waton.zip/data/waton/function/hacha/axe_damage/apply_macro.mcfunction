attribute @s generic.attack_damage modifier remove waton:axe_damage_bonus
$attribute @s generic.attack_damage modifier add waton:axe_damage_bonus $(value) add_value
