scoreboard players set @s waton_axe_damage_bonus 0
execute if score @s waton_axe_damage_tier matches 1 run scoreboard players set @s waton_axe_damage_bonus 2
execute if score @s waton_axe_damage_tier matches 2 run scoreboard players set @s waton_axe_damage_bonus 5
execute if score @s waton_axe_damage_tier matches 3 run scoreboard players set @s waton_axe_damage_bonus 9
execute if score @s waton_axe_damage_tier matches 4 run scoreboard players set @s waton_axe_damage_bonus 14
execute if score @s waton_axe_damage_tier matches 5 run scoreboard players set @s waton_axe_damage_bonus 21
execute if score @s waton_axe_damage_tier matches 6.. run scoreboard players set @s waton_axe_damage_bonus 30
