# (en desuso) el bonus de astillas fue reemplazado por regeneración pasiva; ver waton:hacha/regen/apply
