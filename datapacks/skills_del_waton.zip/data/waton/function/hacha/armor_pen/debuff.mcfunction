tag @s add waton_armor_pen_debuff
scoreboard players set @s waton_armor_pen_timer 60
attribute @s generic.armor modifier remove waton:armor_pen
attribute @s generic.armor modifier add waton:armor_pen -4 add_value
attribute @s generic.armor_toughness modifier remove waton:armor_pen
attribute @s generic.armor_toughness modifier add waton:armor_pen -2 add_value
