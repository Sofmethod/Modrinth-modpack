attribute @s generic.armor modifier remove waton:armor_pen
attribute @s generic.armor_toughness modifier remove waton:armor_pen
tag @s remove waton_armor_pen_debuff
scoreboard players reset @s waton_armor_pen_timer
