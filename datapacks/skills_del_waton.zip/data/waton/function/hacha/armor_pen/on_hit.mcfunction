execute if entity @s[tag=waton_hacha_armor_pen] if items entity @s weapon.mainhand #minecraft:axes as @e[type=!player,distance=..4,sort=nearest,limit=1] run function waton:hacha/armor_pen/debuff
advancement revoke @s only waton:hacha/axe_hit_trigger
