execute as @a run function waton:hacha/axe_damage/tier_to_value
execute as @a if score @s waton_axe_damage_bonus matches 1.. if items entity @s weapon.mainhand #minecraft:axes run function waton:hacha/axe_damage/apply
execute as @a unless items entity @s weapon.mainhand #minecraft:axes run attribute @s generic.attack_damage modifier remove waton:axe_damage_bonus
execute as @a if score @s waton_axe_damage_bonus matches ..0 run attribute @s generic.attack_damage modifier remove waton:axe_damage_bonus
