execute as @e[tag=waton_armor_pen_debuff] run scoreboard players remove @s waton_armor_pen_timer 1
execute as @e[tag=waton_armor_pen_debuff,scores={waton_armor_pen_timer=..0}] run function waton:hacha/armor_pen/clear_debuff
