execute as @s if score @s waton_tanque_escudo_lvl matches 1.. run effect give @s minecraft:absorption 100 0 true
execute as @s at @s if score @s waton_tanque_escudo_lvl matches 2.. as @e[type=!minecraft:player,distance=..3,sort=nearest,limit=1] run damage @s 3 minecraft:generic
execute as @s if score @s waton_tanque_escudo_lvl matches 3.. run effect give @s minecraft:resistance 60 1 true
