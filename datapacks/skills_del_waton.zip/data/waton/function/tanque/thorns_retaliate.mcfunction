execute as @s at @s if score @s waton_tanque_espinas_lvl matches 1 as @e[type=!minecraft:player,distance=..3,sort=nearest,limit=1] run damage @s 4 minecraft:generic
execute as @s at @s if score @s waton_tanque_espinas_lvl matches 2 as @e[type=!minecraft:player,distance=..3,sort=nearest,limit=1] run damage @s 8 minecraft:generic
execute as @s at @s if score @s waton_tanque_espinas_lvl matches 3 as @e[type=!minecraft:player,distance=..3,sort=nearest,limit=1] run damage @s 14 minecraft:generic
advancement revoke @s only waton:tanque/thorns_hit_trigger
advancement revoke @s only waton:tanque/thorns_hit_trigger_ranged
