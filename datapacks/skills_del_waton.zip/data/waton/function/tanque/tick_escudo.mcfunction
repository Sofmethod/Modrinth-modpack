execute as @a if score @s waton_shield_stat > @s waton_shield_prev run function waton:tanque/shield_block_counter
execute as @a run scoreboard players operation @s waton_shield_prev = @s waton_shield_stat
