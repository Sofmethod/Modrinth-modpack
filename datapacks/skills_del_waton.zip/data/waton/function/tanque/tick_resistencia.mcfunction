execute as @a[scores={waton_tanque_res_lvl=1}] run effect give @s minecraft:resistance 5 0 true
execute as @a[scores={waton_tanque_res_lvl=2}] run effect give @s minecraft:resistance 5 1 true
execute as @a[scores={waton_tanque_res_lvl=3}] run effect give @s minecraft:resistance 5 2 true
execute as @a[scores={waton_tanque_res_lvl=4}] run effect give @s minecraft:resistance 5 3 true
