effect give @s minecraft:resistance 200 3 true
effect give @s minecraft:regeneration 200 1 true
scoreboard players set @s waton_muralla_cd 6000
execute if score @s waton_tanque_muralla_mejorada matches 1.. run effect give @s minecraft:resistance 320 3 true
execute if score @s waton_tanque_muralla_mejorada matches 1.. run effect give @s minecraft:regeneration 320 1 true
execute if score @s waton_tanque_muralla_mejorada matches 1.. run scoreboard players set @s waton_muralla_cd 3600
title @s actionbar {"text":"¡Última Muralla activada!","color":"gold"}
