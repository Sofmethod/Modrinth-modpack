execute as @a[tag=waton_tanque_muralla] if score @s waton_muralla_cd matches 0 if score @s waton_health matches ..4 run function waton:tanque/muralla_trigger
execute as @a[tag=waton_tanque_muralla] if score @s waton_muralla_cd matches 1.. run scoreboard players remove @s waton_muralla_cd 1
