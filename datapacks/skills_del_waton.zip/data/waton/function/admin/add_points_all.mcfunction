# Uso: /function waton:admin/add_points_all {target:"NombreJugador",amount:50}
# (target puede ser "@s" para dartelo a ti mismo, o el nombre/selector de otro jugador)
$puffish_skills points add $(target) guerrero $(amount)
$puffish_skills points add $(target) tanque $(amount)
$puffish_skills points add $(target) tala_mineria_excavado $(amount)
$puffish_skills points add $(target) agricultor_herrero $(amount)
$puffish_skills points add $(target) maestria_del_equipo $(amount)
$puffish_skills points add $(target) exploracion $(amount)
$tellraw $(target) [{"text":"[Gremio] ","color":"gold"},{"text":"Recibiste ","color":"gray"},{"text":"$(amount)","color":"yellow"},{"text":" puntos en los 6 arboles de habilidades.","color":"gray"}]
