scoreboard players set #gremio_cria waton_gremio_boost 0
execute as @a[scores={waton_gremio_cria_lvl=1}] run scoreboard players set #gremio_cria waton_gremio_boost 750
execute as @a[scores={waton_gremio_cria_lvl=2}] run scoreboard players set #gremio_cria waton_gremio_boost 2500
execute as @a[scores={waton_gremio_cria_lvl=3..}] run scoreboard players set #gremio_cria waton_gremio_boost 999999
execute as @a[scores={waton_gremio_cria_lvl=1..}] at @s run function waton:agricultor/cria_scan_player
