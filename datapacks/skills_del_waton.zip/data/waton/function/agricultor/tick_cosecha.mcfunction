# Conteo de items en inventario (funciona con cualquier metodo de cosecha, incluido cosechar sin romper el bloque)
execute as @a store result score @s waton_stat_wheat run clear @s minecraft:wheat 0
execute as @a store result score @s waton_stat_carrots run clear @s minecraft:carrot 0
execute as @a store result score @s waton_stat_potatoes run clear @s minecraft:potato 0
execute as @a store result score @s waton_stat_beetroots run clear @s minecraft:beetroot 0
execute as @a store result score @s waton_stat_nether_wart run clear @s minecraft:nether_wart 0
execute as @a store result score @s waton_stat_cocoa run clear @s minecraft:cocoa_beans 0
execute as @a store result score @s waton_stat_melon run clear @s minecraft:melon_slice 0
execute as @a store result score @s waton_stat_pumpkin run clear @s minecraft:pumpkin 0
execute as @a store result score @s waton_stat_fd_cabbages run clear @s farmersdelight:cabbage 0
execute as @a store result score @s waton_stat_fd_onions run clear @s farmersdelight:onion 0
execute as @a store result score @s waton_stat_fd_tomatoes run clear @s farmersdelight:tomato 0
execute as @a store result score @s waton_stat_fd_rice run clear @s farmersdelight:rice 0
execute as @a store result score @s waton_stat_pitcher run clear @s minecraft:pitcher_plant 0

execute as @a at @s if score @s waton_gremio_cosecha_lvl matches 1.. if score @s waton_stat_wheat > @s waton_stat_wheat_prev run function waton:agricultor/cosecha_roll {item:"minecraft:wheat"}
execute as @a at @s if score @s waton_gremio_cosecha_lvl matches 1.. if score @s waton_stat_carrots > @s waton_stat_carrots_prev run function waton:agricultor/cosecha_roll {item:"minecraft:carrot"}
execute as @a at @s if score @s waton_gremio_cosecha_lvl matches 1.. if score @s waton_stat_potatoes > @s waton_stat_potatoes_prev run function waton:agricultor/cosecha_roll {item:"minecraft:potato"}
execute as @a at @s if score @s waton_gremio_cosecha_lvl matches 1.. if score @s waton_stat_beetroots > @s waton_stat_beetroots_prev run function waton:agricultor/cosecha_roll {item:"minecraft:beetroot"}
execute as @a at @s if score @s waton_gremio_cosecha_lvl matches 1.. if score @s waton_stat_nether_wart > @s waton_stat_nether_wart_prev run function waton:agricultor/cosecha_roll {item:"minecraft:nether_wart"}
execute as @a at @s if score @s waton_gremio_cosecha_lvl matches 1.. if score @s waton_stat_cocoa > @s waton_stat_cocoa_prev run function waton:agricultor/cosecha_roll {item:"minecraft:cocoa_beans"}
execute as @a at @s if score @s waton_gremio_cosecha_lvl matches 1.. if score @s waton_stat_melon > @s waton_stat_melon_prev run function waton:agricultor/cosecha_roll {item:"minecraft:melon_slice"}
execute as @a at @s if score @s waton_gremio_cosecha_lvl matches 1.. if score @s waton_stat_pumpkin > @s waton_stat_pumpkin_prev run function waton:agricultor/cosecha_roll {item:"minecraft:pumpkin"}
execute as @a at @s if score @s waton_gremio_cosecha_lvl matches 1.. if score @s waton_stat_fd_cabbages > @s waton_stat_fd_cabbages_prev run function waton:agricultor/cosecha_roll {item:"farmersdelight:cabbage"}
execute as @a at @s if score @s waton_gremio_cosecha_lvl matches 1.. if score @s waton_stat_fd_onions > @s waton_stat_fd_onions_prev run function waton:agricultor/cosecha_roll {item:"farmersdelight:onion"}
execute as @a at @s if score @s waton_gremio_cosecha_lvl matches 1.. if score @s waton_stat_fd_tomatoes > @s waton_stat_fd_tomatoes_prev run function waton:agricultor/cosecha_roll {item:"farmersdelight:tomato"}
execute as @a at @s if score @s waton_gremio_cosecha_lvl matches 1.. if score @s waton_stat_fd_rice > @s waton_stat_fd_rice_prev run function waton:agricultor/cosecha_roll {item:"farmersdelight:rice"}
execute as @a at @s if score @s waton_gremio_cosecha_lvl matches 1.. if score @s waton_stat_pitcher > @s waton_stat_pitcher_prev run function waton:agricultor/cosecha_roll {item:"minecraft:pitcher_plant"}
execute as @a run scoreboard players operation @s waton_stat_wheat_prev = @s waton_stat_wheat
execute as @a run scoreboard players operation @s waton_stat_carrots_prev = @s waton_stat_carrots
execute as @a run scoreboard players operation @s waton_stat_potatoes_prev = @s waton_stat_potatoes
execute as @a run scoreboard players operation @s waton_stat_beetroots_prev = @s waton_stat_beetroots
execute as @a run scoreboard players operation @s waton_stat_nether_wart_prev = @s waton_stat_nether_wart
execute as @a run scoreboard players operation @s waton_stat_cocoa_prev = @s waton_stat_cocoa
execute as @a run scoreboard players operation @s waton_stat_melon_prev = @s waton_stat_melon
execute as @a run scoreboard players operation @s waton_stat_pumpkin_prev = @s waton_stat_pumpkin
execute as @a run scoreboard players operation @s waton_stat_fd_cabbages_prev = @s waton_stat_fd_cabbages
execute as @a run scoreboard players operation @s waton_stat_fd_onions_prev = @s waton_stat_fd_onions
execute as @a run scoreboard players operation @s waton_stat_fd_tomatoes_prev = @s waton_stat_fd_tomatoes
execute as @a run scoreboard players operation @s waton_stat_fd_rice_prev = @s waton_stat_fd_rice
execute as @a run scoreboard players operation @s waton_stat_pitcher_prev = @s waton_stat_pitcher
