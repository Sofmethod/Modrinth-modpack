scoreboard players set @s waton_item_age 999
execute store result score @s waton_item_age run data get entity @s Age
execute if score @s waton_item_age matches 0..4 unless entity @s[tag=waton_gremio_dup] run function waton:agricultor/loot_duplicate_roll
