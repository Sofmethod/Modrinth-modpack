execute as @a store result score @s waton_food_cur run data get entity @s foodLevel
execute as @a if score @s waton_gremio_comida_lvl matches 1.. if score @s waton_food_cur > @s waton_food_prev run function waton:agricultor/comida_bonus
execute as @a run scoreboard players operation @s waton_food_prev = @s waton_food_cur
