function waton:agricultor/kill_bonus {item:"minecraft:bone",adv:"waton:agricultor/kill/skeleton"}
