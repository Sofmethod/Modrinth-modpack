function waton:agricultor/kill_bonus {item:"minecraft:beef",adv:"waton:agricultor/kill/bison"}
