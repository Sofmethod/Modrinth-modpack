function waton:agricultor/kill_bonus {item:"minecraft:string",adv:"waton:agricultor/kill/spider"}
