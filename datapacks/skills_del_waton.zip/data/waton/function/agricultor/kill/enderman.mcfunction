function waton:agricultor/kill_bonus {item:"minecraft:ender_pearl",adv:"waton:agricultor/kill/enderman"}
