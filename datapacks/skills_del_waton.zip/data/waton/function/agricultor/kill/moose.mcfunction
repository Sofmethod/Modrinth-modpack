function waton:agricultor/kill_bonus {item:"alexsmobs:moose_ribs",adv:"waton:agricultor/kill/moose"}
