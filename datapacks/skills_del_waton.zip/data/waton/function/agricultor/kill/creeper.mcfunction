function waton:agricultor/kill_bonus {item:"minecraft:gunpowder",adv:"waton:agricultor/kill/creeper"}
