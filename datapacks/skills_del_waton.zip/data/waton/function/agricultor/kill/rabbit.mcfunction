function waton:agricultor/kill_bonus {item:"minecraft:rabbit",adv:"waton:agricultor/kill/rabbit"}
