function waton:agricultor/kill_bonus {item:"minecraft:rotten_flesh",adv:"waton:agricultor/kill/husk"}
