function waton:agricultor/kill_bonus {item:"minecraft:feather",adv:"waton:agricultor/kill/emu"}
