function waton:agricultor/kill_bonus {item:"alexsmobs:bear_fur",adv:"waton:agricultor/kill/grizzly_bear"}
