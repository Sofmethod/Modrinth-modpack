function waton:agricultor/kill_bonus {item:"minecraft:copper_ingot",adv:"waton:agricultor/kill/drowned"}
