function waton:agricultor/kill_bonus {item:"minecraft:mutton",adv:"waton:agricultor/kill/gazelle"}
