function waton:agricultor/kill_bonus {item:"minecraft:glowstone_dust",adv:"waton:agricultor/kill/witch"}
