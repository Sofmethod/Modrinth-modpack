function waton:agricultor/kill_bonus {item:"alexsmobs:kangaroo_meat",adv:"waton:agricultor/kill/kangaroo"}
