function waton:agricultor/kill_bonus {item:"minecraft:porkchop",adv:"waton:agricultor/kill/pig"}
