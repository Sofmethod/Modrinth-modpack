execute store result score @s waton_gremio_rng run random value 1..100
execute if score @s waton_gremio_doble_lvl matches 1 if score @s waton_gremio_rng matches ..10 run give @s minecraft:netherite_shovel 1
execute if score @s waton_gremio_doble_lvl matches 2 if score @s waton_gremio_rng matches ..20 run give @s minecraft:netherite_shovel 1
execute if score @s waton_gremio_doble_lvl matches 3 if score @s waton_gremio_rng matches ..30 run give @s minecraft:netherite_shovel 1
advancement revoke @s only waton:agricultor/craft/netherite_shovel
