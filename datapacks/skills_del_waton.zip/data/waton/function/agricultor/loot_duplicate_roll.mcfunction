execute store result score @s waton_gremio_rng run random value 1..100
execute if score #gremio_loot waton_gremio_boost matches 1 if score @s waton_gremio_rng matches ..50 run function waton:agricultor/loot_duplicate_do
execute if score #gremio_loot waton_gremio_boost matches 2.. run function waton:agricultor/loot_duplicate_do
execute store result score @s waton_gremio_rng run random value 1..100
execute if score #gremio_loot waton_gremio_boost matches 2 if score @s waton_gremio_rng matches ..50 run function waton:agricultor/loot_duplicate_do
execute if score #gremio_loot waton_gremio_boost matches 3.. run function waton:agricultor/loot_duplicate_do
