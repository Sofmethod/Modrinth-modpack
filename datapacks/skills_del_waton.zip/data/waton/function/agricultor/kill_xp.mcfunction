execute if score @s waton_gremio_xp_lvl matches 1 run summon minecraft:experience_orb ~ ~ ~ {Value:2}
execute if score @s waton_gremio_xp_lvl matches 2 run summon minecraft:experience_orb ~ ~ ~ {Value:5}
advancement revoke @s only waton:agricultor/kill_xp
