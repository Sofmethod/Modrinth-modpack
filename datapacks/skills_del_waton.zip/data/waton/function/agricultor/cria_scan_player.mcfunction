execute as @e[distance=..14] at @s run function waton:agricultor/cria_check
