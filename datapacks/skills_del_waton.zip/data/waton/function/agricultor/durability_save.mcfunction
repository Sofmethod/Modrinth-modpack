execute store result score @s waton_gremio_rng run random value 1..100
execute if score @s waton_gremio_durab_lvl matches 1 if score @s waton_gremio_rng matches ..15 run item modify entity @s weapon.mainhand waton:agricultor/repair_small
execute if score @s waton_gremio_durab_lvl matches 2 if score @s waton_gremio_rng matches ..25 run item modify entity @s weapon.mainhand waton:agricultor/repair_small
execute if score @s waton_gremio_durab_lvl matches 3 if score @s waton_gremio_rng matches ..35 run item modify entity @s weapon.mainhand waton:agricultor/repair_small
execute if score @s waton_gremio_durab_lvl matches 4 if score @s waton_gremio_rng matches ..50 run item modify entity @s weapon.mainhand waton:agricultor/repair_small
advancement revoke @s only waton:agricultor/durability_trigger
