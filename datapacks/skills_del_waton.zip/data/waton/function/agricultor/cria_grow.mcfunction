scoreboard players operation @s waton_age_tmp += #gremio_cria waton_gremio_boost
execute if score @s waton_age_tmp matches 0.. run scoreboard players set @s waton_age_tmp 0
execute store result entity @s Age int 1 run scoreboard players get @s waton_age_tmp
