execute if score @s waton_gremio_comida_lvl matches 1 run effect give @s minecraft:saturation 1 0 true
execute if score @s waton_gremio_comida_lvl matches 2 run effect give @s minecraft:saturation 1 1 true
execute if score @s waton_gremio_comida_lvl matches 3 run effect give @s minecraft:saturation 1 2 true
execute if score @s waton_gremio_comida_lvl matches 4 run effect give @s minecraft:saturation 1 3 true
execute if score @s waton_gremio_comida_lvl matches 4 if score @s waton_food_cur matches 20 run effect give @s minecraft:regeneration 60 0 true
