tag @s add waton_gremio_dup_src
execute at @s run summon minecraft:item ~ ~ ~ {Tags:["waton_gremio_dup_new","waton_gremio_dup"],PickupDelay:0s}
execute as @e[type=minecraft:item,tag=waton_gremio_dup_new,limit=1,sort=nearest] run data modify entity @s Item set from entity @e[type=minecraft:item,tag=waton_gremio_dup_src,limit=1,sort=nearest] Item
execute as @e[type=minecraft:item,tag=waton_gremio_dup_new] run tag @s remove waton_gremio_dup_new
tag @s remove waton_gremio_dup_src
