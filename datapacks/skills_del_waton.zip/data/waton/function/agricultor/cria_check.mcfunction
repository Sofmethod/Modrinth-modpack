scoreboard players set @s waton_age_tmp 1
execute store result score @s waton_age_tmp run data get entity @s Age
execute if score @s waton_age_tmp matches ..-1 run function waton:agricultor/cria_grow
