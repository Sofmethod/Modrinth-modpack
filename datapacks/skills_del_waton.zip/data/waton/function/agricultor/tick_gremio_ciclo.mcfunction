scoreboard players add #gremio_growth waton_gremio_timer 1
execute if score #gremio_growth waton_gremio_timer matches 20.. run scoreboard players set #gremio_growth waton_gremio_timer 0
execute if score #gremio_growth waton_gremio_timer matches 0 run function waton:agricultor/tick_crecimiento

scoreboard players add #gremio_cria_ciclo waton_gremio_timer 1
execute if score #gremio_cria_ciclo waton_gremio_timer matches 5.. run scoreboard players set #gremio_cria_ciclo waton_gremio_timer 0
execute if score #gremio_cria_ciclo waton_gremio_timer matches 0 run function waton:agricultor/cria_scan
