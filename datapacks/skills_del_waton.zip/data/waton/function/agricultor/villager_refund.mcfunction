execute if score @s waton_gremio_comercio_lvl matches 1 run give @s minecraft:emerald 1
execute if score @s waton_gremio_comercio_lvl matches 2 run give @s minecraft:emerald 2
advancement revoke @s only waton:agricultor/villager_trade
