execute store result score #gremio_loot waton_gremio_boost run scoreboard players get @s waton_gremio_loot_lvl
execute as @e[type=minecraft:item,distance=..5] at @s run function waton:agricultor/loot_check_fresh
scoreboard players set #gremio_loot waton_gremio_boost 0
advancement revoke @s only waton:agricultor/kill_loot_boost
