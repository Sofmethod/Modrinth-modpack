$give @s $(item) 1
title @s actionbar {"text":"Botín extra del Gremio","color":"gold"}
playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.6 1.2
