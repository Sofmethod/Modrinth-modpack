execute store result score @s waton_gremio_rng run random value 1..100
$execute if score @s waton_gremio_cosecha_lvl matches 1 if score @s waton_gremio_rng matches ..15 run function waton:agricultor/cosecha_dar {item:$(item)}
$execute if score @s waton_gremio_cosecha_lvl matches 2 if score @s waton_gremio_rng matches ..30 run function waton:agricultor/cosecha_dar {item:$(item)}
$execute if score @s waton_gremio_cosecha_lvl matches 3 if score @s waton_gremio_rng matches ..100 run function waton:agricultor/cosecha_dar {item:$(item)}
execute store result score @s waton_gremio_rng run random value 1..100
execute if entity @s[tag=waton_gremio_legado] if score @s waton_gremio_rng matches ..10 run give @s minecraft:emerald 1
