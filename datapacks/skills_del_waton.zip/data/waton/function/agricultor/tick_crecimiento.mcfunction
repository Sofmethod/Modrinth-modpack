execute as @a[scores={waton_gremio_crecimiento_lvl=1}] at @s run function waton:agricultor/tick_crecimiento_r2
execute as @a[scores={waton_gremio_crecimiento_lvl=2..}] at @s run function waton:agricultor/tick_crecimiento_r3
