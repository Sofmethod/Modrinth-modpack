execute store result score @s waton_gremio_rng run random value 1..100
$execute if score @s waton_gremio_botin_lvl matches 1 if score @s waton_gremio_rng matches ..30 run function waton:agricultor/kill_dar {item:$(item)}
$execute if score @s waton_gremio_botin_lvl matches 2 if score @s waton_gremio_rng matches ..100 run function waton:agricultor/kill_dar {item:$(item)}
execute store result score @s waton_gremio_rng run random value 1..100
execute if entity @s[tag=waton_gremio_legado] if score @s waton_gremio_rng matches ..10 run give @s minecraft:emerald 1
$advancement revoke @s only $(adv)
