$give @s $(item) 1
title @s actionbar {"text":"Cosecha extra del Gremio","color":"green"}
playsound minecraft:entity.villager.yes master @s ~ ~ ~ 0.6 1.4
