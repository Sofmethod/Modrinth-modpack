scoreboard players set @a waton_equip_violation 0

execute as @a[tag=!waton_tier_madera] if items entity @s weapon.mainhand #waton:tier_madera_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_madera] if items entity @s armor.head #waton:tier_madera_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_madera] if items entity @s armor.chest #waton:tier_madera_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_madera] if items entity @s armor.legs #waton:tier_madera_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_madera] if items entity @s armor.feet #waton:tier_madera_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_piedra] if items entity @s weapon.mainhand #waton:tier_piedra_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_piedra] if items entity @s armor.head #waton:tier_piedra_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_piedra] if items entity @s armor.chest #waton:tier_piedra_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_piedra] if items entity @s armor.legs #waton:tier_piedra_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_piedra] if items entity @s armor.feet #waton:tier_piedra_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_hierro] if items entity @s weapon.mainhand #waton:tier_hierro_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_hierro] if items entity @s armor.head #waton:tier_hierro_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_hierro] if items entity @s armor.chest #waton:tier_hierro_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_hierro] if items entity @s armor.legs #waton:tier_hierro_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_hierro] if items entity @s armor.feet #waton:tier_hierro_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_oro] if items entity @s weapon.mainhand #waton:tier_oro_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_oro] if items entity @s armor.head #waton:tier_oro_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_oro] if items entity @s armor.chest #waton:tier_oro_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_oro] if items entity @s armor.legs #waton:tier_oro_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_oro] if items entity @s armor.feet #waton:tier_oro_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_diamante] if items entity @s weapon.mainhand #waton:tier_diamante_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_diamante] if items entity @s armor.head #waton:tier_diamante_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_diamante] if items entity @s armor.chest #waton:tier_diamante_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_diamante] if items entity @s armor.legs #waton:tier_diamante_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_diamante] if items entity @s armor.feet #waton:tier_diamante_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_netherite] if items entity @s weapon.mainhand #waton:tier_netherite_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_netherite] if items entity @s armor.head #waton:tier_netherite_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_netherite] if items entity @s armor.chest #waton:tier_netherite_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_netherite] if items entity @s armor.legs #waton:tier_netherite_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_netherite] if items entity @s armor.feet #waton:tier_netherite_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_gobber] if items entity @s weapon.mainhand #waton:tier_gobber_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_gobber] if items entity @s armor.head #waton:tier_gobber_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_gobber] if items entity @s armor.chest #waton:tier_gobber_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_gobber] if items entity @s armor.legs #waton:tier_gobber_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_gobber] if items entity @s armor.feet #waton:tier_gobber_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_gobber_nether] if items entity @s weapon.mainhand #waton:tier_gobber_nether_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_gobber_nether] if items entity @s armor.head #waton:tier_gobber_nether_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_gobber_nether] if items entity @s armor.chest #waton:tier_gobber_nether_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_gobber_nether] if items entity @s armor.legs #waton:tier_gobber_nether_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_gobber_nether] if items entity @s armor.feet #waton:tier_gobber_nether_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_gobber_end] if items entity @s weapon.mainhand #waton:tier_gobber_end_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_gobber_end] if items entity @s armor.head #waton:tier_gobber_end_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_gobber_end] if items entity @s armor.chest #waton:tier_gobber_end_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_gobber_end] if items entity @s armor.legs #waton:tier_gobber_end_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_gobber_end] if items entity @s armor.feet #waton:tier_gobber_end_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_wyvern] if items entity @s weapon.mainhand #waton:tier_wyvern_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_wyvern] if items entity @s armor.chest #waton:tier_wyvern_chest run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_draconic] if items entity @s weapon.mainhand #waton:tier_draconic_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_draconic] if items entity @s armor.chest #waton:tier_draconic_chest run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_chaotic] if items entity @s weapon.mainhand #waton:tier_chaotic_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_chaotic] if items entity @s armor.chest #waton:tier_chaotic_chest run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_if_copper] if items entity @s weapon.mainhand #waton:tier_if_copper_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_if_copper] if items entity @s armor.head #waton:tier_if_copper_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_if_copper] if items entity @s armor.chest #waton:tier_if_copper_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_if_copper] if items entity @s armor.legs #waton:tier_if_copper_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_if_copper] if items entity @s armor.feet #waton:tier_if_copper_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_if_silver] if items entity @s weapon.mainhand #waton:tier_if_silver_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_if_silver] if items entity @s armor.head #waton:tier_if_silver_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_if_silver] if items entity @s armor.chest #waton:tier_if_silver_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_if_silver] if items entity @s armor.legs #waton:tier_if_silver_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_if_silver] if items entity @s armor.feet #waton:tier_if_silver_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_if_dragonbone] if items entity @s weapon.mainhand #waton:tier_if_dragonbone_tools run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_if_dragonsteel] if items entity @s weapon.mainhand #waton:tier_if_dragonsteel_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_if_dragonsteel] if items entity @s armor.head #waton:tier_if_dragonsteel_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_if_dragonsteel] if items entity @s armor.chest #waton:tier_if_dragonsteel_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_if_dragonsteel] if items entity @s armor.legs #waton:tier_if_dragonsteel_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_if_dragonsteel] if items entity @s armor.feet #waton:tier_if_dragonsteel_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_be_thallasium] if items entity @s weapon.mainhand #waton:tier_be_thallasium_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_be_thallasium] if items entity @s armor.head #waton:tier_be_thallasium_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_be_thallasium] if items entity @s armor.chest #waton:tier_be_thallasium_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_be_thallasium] if items entity @s armor.legs #waton:tier_be_thallasium_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_be_thallasium] if items entity @s armor.feet #waton:tier_be_thallasium_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_be_terminite] if items entity @s weapon.mainhand #waton:tier_be_terminite_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_be_terminite] if items entity @s armor.head #waton:tier_be_terminite_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_be_terminite] if items entity @s armor.chest #waton:tier_be_terminite_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_be_terminite] if items entity @s armor.legs #waton:tier_be_terminite_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_be_terminite] if items entity @s armor.feet #waton:tier_be_terminite_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_be_aeternium] if items entity @s weapon.mainhand #waton:tier_be_aeternium_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_be_aeternium] if items entity @s armor.head #waton:tier_be_aeternium_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_be_aeternium] if items entity @s armor.chest #waton:tier_be_aeternium_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_be_aeternium] if items entity @s armor.legs #waton:tier_be_aeternium_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_be_aeternium] if items entity @s armor.feet #waton:tier_be_aeternium_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_bf_copper] if items entity @s weapon.mainhand #waton:tier_bf_copper_tools run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_bf_amethyst] if items entity @s weapon.mainhand #waton:tier_bf_amethyst_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_bf_amethyst] if items entity @s armor.head #waton:tier_bf_amethyst_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_bf_amethyst] if items entity @s armor.chest #waton:tier_bf_amethyst_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_bf_amethyst] if items entity @s armor.legs #waton:tier_bf_amethyst_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_bf_amethyst] if items entity @s armor.feet #waton:tier_bf_amethyst_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_bf_emerald] if items entity @s weapon.mainhand #waton:tier_bf_emerald_tools run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_bf_emerald] if items entity @s armor.head #waton:tier_bf_emerald_head run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_bf_emerald] if items entity @s armor.chest #waton:tier_bf_emerald_chest run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_bf_emerald] if items entity @s armor.legs #waton:tier_bf_emerald_legs run scoreboard players set @s waton_equip_violation 1
execute as @a[tag=!waton_tier_bf_emerald] if items entity @s armor.feet #waton:tier_bf_emerald_feet run scoreboard players set @s waton_equip_violation 1

execute as @a[tag=!waton_tier_cat_black_steel] if items entity @s weapon.mainhand #waton:tier_cat_black_steel_tools run scoreboard players set @s waton_equip_violation 1

execute as @a[scores={waton_equip_violation=1}] run effect give @s minecraft:slowness 5 6 true
execute as @a[scores={waton_equip_violation=1}] run effect give @s minecraft:weakness 5 2 true
execute as @a[scores={waton_equip_violation=1}] run effect give @s minecraft:mining_fatigue 5 3 true
execute as @a[scores={waton_equip_violation=0}] run effect clear @s minecraft:slowness
execute as @a[scores={waton_equip_violation=0}] run effect clear @s minecraft:weakness
execute as @a[scores={waton_equip_violation=0}] run effect clear @s minecraft:mining_fatigue
