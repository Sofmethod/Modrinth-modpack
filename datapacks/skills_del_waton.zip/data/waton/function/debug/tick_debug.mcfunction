execute as @a run scoreboard players enable @s waton_debug_guerrero
execute as @a if score @s waton_debug_guerrero matches 1.. run function waton:debug/dump_guerrero
execute as @a if score @s waton_debug_guerrero matches 1.. run scoreboard players set @s waton_debug_guerrero 0
