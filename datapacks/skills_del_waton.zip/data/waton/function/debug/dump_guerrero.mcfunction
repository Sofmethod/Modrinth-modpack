tellraw @s [{"text": "=== Diagnostico Guerrero ===", "color": "gold", "bold": true}]
scoreboard players set @s waton_debug_val -999999
execute store result score @s waton_debug_val run attribute @s generic.attack_damage modifier value get waton:sword_damage_bonus
execute if score @s waton_debug_val matches -999999 run tellraw @s [{"text": "  Espada (Opazo): ", "color": "gray"}, {"text": "objetivo=", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_guerrero_dmg_bonus"}}, {"text": " | modificador: sin arma correspondiente en mano", "color": "yellow"}]
execute unless score @s waton_debug_val matches -999999 if score @s waton_guerrero_dmg_bonus = @s waton_debug_val run tellraw @s [{"text": "  Espada (Opazo): ", "color": "gray"}, {"text": "objetivo=", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_guerrero_dmg_bonus"}}, {"text": " | modificador=", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_debug_val"}}, {"text": "  OK", "color": "green", "bold": true}]
execute unless score @s waton_debug_val matches -999999 unless score @s waton_guerrero_dmg_bonus = @s waton_debug_val run tellraw @s [{"text": "  Espada (Opazo): ", "color": "gray"}, {"text": "objetivo=", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_guerrero_dmg_bonus"}}, {"text": " | modificador=", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_debug_val"}}, {"text": "  DESINCRONIZADO", "color": "red", "bold": true}]
scoreboard players set @s waton_debug_val -999999
execute store result score @s waton_debug_val run attribute @s generic.attack_damage modifier value get waton:axe_damage_bonus
execute if score @s waton_debug_val matches -999999 run tellraw @s [{"text": "  Hacha: ", "color": "gray"}, {"text": "objetivo=", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_axe_damage_bonus"}}, {"text": " | modificador: sin arma correspondiente en mano", "color": "yellow"}]
execute unless score @s waton_debug_val matches -999999 if score @s waton_axe_damage_bonus = @s waton_debug_val run tellraw @s [{"text": "  Hacha: ", "color": "gray"}, {"text": "objetivo=", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_axe_damage_bonus"}}, {"text": " | modificador=", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_debug_val"}}, {"text": "  OK", "color": "green", "bold": true}]
execute unless score @s waton_debug_val matches -999999 unless score @s waton_axe_damage_bonus = @s waton_debug_val run tellraw @s [{"text": "  Hacha: ", "color": "gray"}, {"text": "objetivo=", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_axe_damage_bonus"}}, {"text": " | modificador=", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_debug_val"}}, {"text": "  DESINCRONIZADO", "color": "red", "bold": true}]
tellraw @s [{"text": "-- Totales de atributo (base + todos los bonos activos, x100 = %) --", "color": "gray"}]
execute store result score @s waton_debug_val run attribute @s generic.attack_damage get 1
tellraw @s [{"text": "  generic.attack_damage total: ", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_debug_val"}}]
execute store result score @s waton_debug_val run attribute @s generic.attack_speed get 1
tellraw @s [{"text": "  generic.attack_speed total: ", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_debug_val"}}]
execute store result score @s waton_debug_val run attribute @s puffish_attributes:sprinting_speed get 1
tellraw @s [{"text": "  puffish_attributes:sprinting_speed total: ", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_debug_val"}}]
execute store result score @s waton_debug_val run attribute @s apothic_attributes:draw_speed get 100
tellraw @s [{"text": "  apothic_attributes:draw_speed total (x100=%): ", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_debug_val"}}]
execute store result score @s waton_debug_val run attribute @s apothic_attributes:arrow_damage get 100
tellraw @s [{"text": "  apothic_attributes:arrow_damage total (x100=%, ej. 260 = 260%): ", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_debug_val"}}]
execute store result score @s waton_debug_val run attribute @s apothic_attributes:arrow_velocity get 100
tellraw @s [{"text": "  apothic_attributes:arrow_velocity total (x100=%, ej. 165 = 165%): ", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_debug_val"}}]
tellraw @s [{"text": "-- Niveles (Salas / Viera / Pierry) --", "color": "gray"}]
tellraw @s [{"text": "  Critico (Salas) nivel: ", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_guerrero_crit_lvl"}}]
tellraw @s [{"text": "  Vida robada (Viera) nivel: ", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_guerrero_vida_lvl"}}]
tellraw @s [{"text": "  Dash (Pierry) nivel: ", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_guerrero_dash_lvl"}}]
tellraw @s [{"text": "  Racha (Salas) stacks: ", "color": "gray"}, {"score": {"name": "@s", "objective": "waton_racha_stacks"}}]
