execute as @a[tag=waton_autosmelt_owner] unless score @s waton_fundicion matches -2147483648..2147483647 run scoreboard players set @s waton_fundicion 1
execute as @a[tag=waton_autosmelt_owner] run scoreboard players enable @s waton_fundicion
execute as @a[tag=waton_autosmelt_owner] run scoreboard players operation @s waton_fundicion %= #two waton_data
execute as @a[tag=waton_autosmelt_owner] unless score @s waton_fundicion = @s waton_fund_prev run function waton:mineria/autosmelt/notify
execute as @a[tag=waton_autosmelt_owner] run scoreboard players operation @s waton_fund_prev = @s waton_fundicion
