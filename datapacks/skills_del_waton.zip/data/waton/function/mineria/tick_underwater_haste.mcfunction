execute as @a[tag=waton_mineria_agua] at @s if block ~ ~1 ~ minecraft:water run effect give @s minecraft:haste 1 19 true
execute as @a[tag=waton_excavado_agua] at @s if block ~ ~1 ~ minecraft:water run effect give @s minecraft:haste 1 19 true
