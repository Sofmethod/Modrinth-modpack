execute store result score #waton_tmp waton_data run clear @s minecraft:raw_gold 1
execute if score #waton_tmp waton_data matches 1 run give @s minecraft:gold_ingot 1
execute if score #waton_tmp waton_data matches 1 run function waton:mineria/autosmelt/drain_gold
