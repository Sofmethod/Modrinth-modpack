execute if entity @s[tag=waton_mineria_autosmelt] if score @s waton_fundicion matches 1 run function waton:mineria/autosmelt/drain_iron
execute if entity @s[tag=waton_mineria_autosmelt] if score @s waton_fundicion matches 1 run function waton:mineria/autosmelt/drain_copper
execute if entity @s[tag=waton_mineria_autosmelt] if score @s waton_fundicion matches 1 run function waton:mineria/autosmelt/drain_gold
execute if entity @s[tag=waton_mineria_autosmelt_zinc] if score @s waton_fundicion matches 1 run function waton:mineria/autosmelt/drain_zinc
execute if entity @s[tag=waton_mineria_autosmelt_draconium] if score @s waton_fundicion matches 1 run function waton:mineria/autosmelt/drain_draconium
execute if entity @s[tag=waton_excavado_autosmelt] if score @s waton_fundicion matches 1 run function waton:excavado/autosmelt/drain_sand
execute if entity @s[tag=waton_excavado_autosmelt] if score @s waton_fundicion matches 1 run function waton:excavado/autosmelt/drain_red_sand
execute if entity @s[tag=waton_excavado_autosmelt] if score @s waton_fundicion matches 1 run function waton:excavado/autosmelt/drain_clay
execute if entity @s[tag=waton_hacha_autosmelt] if score @s waton_fundicion matches 1 run function waton:hacha/autosmelt/drain_log
advancement revoke @s only waton:mineria/autosmelt_trigger
