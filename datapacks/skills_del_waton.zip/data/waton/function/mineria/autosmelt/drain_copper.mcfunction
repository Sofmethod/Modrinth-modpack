execute store result score #waton_tmp waton_data run clear @s minecraft:raw_copper 1
execute if score #waton_tmp waton_data matches 1 run give @s minecraft:copper_ingot 1
execute if score #waton_tmp waton_data matches 1 run function waton:mineria/autosmelt/drain_copper
