execute store result score #waton_tmp waton_data run clear @s draconicevolution:draconium_dust 1
execute if score #waton_tmp waton_data matches 1 run give @s draconicevolution:draconium_ingot 1
execute if score #waton_tmp waton_data matches 1 run function waton:mineria/autosmelt/drain_draconium
