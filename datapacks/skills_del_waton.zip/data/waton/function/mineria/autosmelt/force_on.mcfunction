scoreboard players enable @s waton_fundicion
scoreboard players set @s waton_fundicion 1
