execute store result score #waton_tmp waton_data run clear @s create:raw_zinc 1
execute if score #waton_tmp waton_data matches 1 run give @s create:zinc_ingot 1
execute if score #waton_tmp waton_data matches 1 run function waton:mineria/autosmelt/drain_zinc
