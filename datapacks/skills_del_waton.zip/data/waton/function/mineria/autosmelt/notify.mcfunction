execute if score @s waton_fundicion matches 1 run tellraw @s [{"text":"Fundicion automatica ","color":"gold"},{"text":"ACTIVADA","color":"green","bold":true}]
execute if score @s waton_fundicion matches 0 run tellraw @s [{"text":"Fundicion automatica ","color":"gold"},{"text":"DESACTIVADA","color":"red","bold":true}]
